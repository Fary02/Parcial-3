# Importacion de libreria;

from random import randint;

# Comienzo de programa;

for i in range (1):
  
  print("\n*****Bienvenido/a*****")
  
  try:
    
    print("1. Jugar");  
    print("2. Salir"); 
    
    opcion = int(input("\nSeleccione una opcion: ")); 
    
    if opcion == 1:
      
      n1 = int(input("\nDigite un numero entero: "));  
      n2 = int(input("Digite un numero entero mayor al anterior: ")); 
      
      numeroRandom = randint(n1,n2);  
    
      
      if n2 > n1: 
        
        vidasPrincipal = 3
        
        vidasAviso = (print(f"\ntienes: {vidasPrincipal} vidas")); 
        
        numeroIntento = input("\nAdivina el numero: "); 
        
        for i in range(3):
        
          if numeroIntento == numeroRandom:
          
            print(f"\nFelicidades el numero: {numeroRandom} es el correcto")  
              
          else:
              
            vidasPrincipal = vidasPrincipal - 1; 
            
            print(f"\nRespuesta incorrecta te quedan: {vidasPrincipal} vidas"); 
            
            numeroIntento = input("\nAdivina el numero: "); 
            
            vidasPrincipal -1
            
            if numeroIntento == numeroRandom:
          
              print(f"\nFelicidades el numero: {numeroRandom} es el correcto")  
              
            else:
              
              vidasPrincipal = vidasPrincipal - 1; 
            
              print(f"\nRespuesta incorrecta te quedan: {vidasPrincipal} vidas"); 
            
              print("Has perdido") 
            
              vidasPrincipal = vidasPrincipal -1
              
              
              if numeroIntento == numeroRandom:
          
                print(f"\nFelicidades el numero: {numeroRandom} es el correcto")
                
              break;  
            
            
              
                
  except Exception:
    
    print("\n¡ERROR!, seleccione una opcion valida"); 