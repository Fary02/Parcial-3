# Bienvenida;

print("\n*****Bienvenido/a*****"); 

pikachu_Roll = 4500;  
  
otaku_Roll = 5000;  
  
pulpo_Venenoso_Roll = 5200; 
  
anguila_Electrica_Roll = 4800; 
  
def valorXcantidad(a,b):
  
  return a * b; 

while True: 
  
  nombre_usuario = str(input("\nPor favor, digite su nombre:")); 
  
  nombre_usuario_Len = len(nombre_usuario); 
  
  if nombre_usuario.isalpha and nombre_usuario_Len >= 3:
  
    # Menu; 

    print("\nMenu:"); 
  
    print("1. Pikachu Roll"); 
    print("2. Otaku Roll"); 
    print("3. Pulpo Venenoso Roll"); 
    print("4. Anguila Electrica Roll"); 
    print("5. Salir"); 
  
  # Solicitud de opcion;
  
    try:
      
      codigo_Descuento = "soyotaku";  
  
      menu_Opcion = int(input("\nDigite una opcion: ")); 
    
      if menu_Opcion == 1:
        
        print(f"\nPikachu Roll tiene un valor de: {pikachu_Roll}"); 
        
        cantidad = int(input("\nSeleccione la cantidad a llevar: "))
        
        if cantidad > 0:
          
          print(f"\nEl subtotal seria de:{valorXcantidad(cantidad,pikachu_Roll)}"); 
          
            
          
        else: 
        
          print("Seleccione una cantidad valida"); 
    
          

        
      else: 
        
        print("Seleccione una opcion valida"); 
        
      cantidad + 1
          
      print(f"{cantidad}"); 
      
    except Exception: print("\n¡ERROR!, seleccione una opcion valida"); 
    
    finally:
    
      print("\nFinalizando pedido"); 
    
      print("\n*****Muchas gracias, vuelva pronto*****"); 
    
  else: 
    
    print("\n¡ERROR!, el nombre debe tener 3 o mas caracteres"); 
  