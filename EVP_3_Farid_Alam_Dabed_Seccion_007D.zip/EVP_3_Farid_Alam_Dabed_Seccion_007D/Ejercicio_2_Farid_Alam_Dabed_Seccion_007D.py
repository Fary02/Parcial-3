# Mensaje bienvendida;

print("\n¡Bienvenido al sistema de gestión de cupos del Gimnasio Titan!"); 

# Definimos cupos; 

cupos_Disponibles = 75; 

 # Definimos reservas;

reservas = 0; 

  # Creacion de functions; 

def reservas_Actualizado(a, b):
  
  return a - b; 

def cancelaciones_Actualizado(a,b):
  
  return a + b; 

def cantidad_Reservas(a, b):
  
  return a + b

def cantidad_Cancelaciones(a, b):
  
  return a - b

 # Definimos cancelaciones;

cancelaciones = 0; 

# Creacion menu; 

while True:

  print("""\n*****MENU PRINCIPAL*****

  1. Cupos disponibles.

  2. Realizar reserva.

  3. Cancelar reserva.

  4. Historial de reservas.

  5. Salir """)
  
  # Intenta;
  
  try:
    
    # Solicitud de ingreso de opcion;
  
    opcion = int(input("\nDigita una opcion: ")); 
    
    # Si opcion 1;
    
    if opcion == 1:
      
      # Mensaje con informativo;
      
      print(f"\nQuedan {reservas_Actualizado(cupos_Disponibles, reservas)} cupos disponibles"); 
      
      # Si opcion 2; 
        
    elif opcion == 2:
      
      # Solicitud de ingreso cantidad;
      
      reservas = int(input(f"\nDigite la cantidad de cupos a reservar: ")); 
      
      # Condiciones para error;
      
      if reservas <= 0 or reservas > cupos_Disponibles:
        
        # Mensaje de error;
        
        print("\n¡ERROR!, ingrese un valor disponible"); 
        
        # Si las condiciones anteriores no se cumplen;
        
      else:
        
        # Mensajes informativos;
        
        print("\nCupo reservado exitosamente"); 
        
        print(f"\nQuedan {reservas_Actualizado(cupos_Disponibles, reservas)} cupos disponibles"); 
        
      # Si opcion 3;
        
    elif opcion == 3:
      
      # Solicitud de ingreso de cantidad a cancelar;
      
      cancelaciones = int(input(f"\nDigite la cantidad de cupos a cancelar: ")); 
      
      # Si las condiciones se cumplen;
      
      if cancelaciones < 0 and cancelaciones > cupos_Disponibles:
        
        # Mensaje de error;
        
        print("\n¡ERROR!, ingrese un valor disponible"); 
        
      # Si lo anterior no se cumple;
        
      else: 
        
        # Mensaje informativo;
        
        print("\nCupo cancelado exitosamente"); 
        
        print(f"\nQuedan {cancelaciones_Actualizado(reservas_Actualizado(cupos_Disponibles, reservas), reservas)} cupos disponibles"); 
        
    # Si opcion 4; 
    
    elif opcion == 4:
      
      # Mensaje informativo;
      
      print(f"\nEsta es la cantidad de reservas realizadas en la sesion: {cantidad_Reservas(reservas, 0)}"); 
      
      # Si se cumple la condicion;
      
      if cancelaciones > 0:
        
        # Mensaje informativo;
        
        print(f"\nEsta es la cantidad de cancelaciones realizadas en la sesion: {cantidad_Cancelaciones(cancelaciones, 1)}"); 
        
    # Si opcion 5;
         
    elif opcion == 5:
      
      # Mensaje de agradecimiento; 
      
      print("\nGracias por utilizar nuestro software, hasta la próxima."); 
      
      # Cierre de programa;
      
      break; 
    
    # Manejo de excepciones;
      
  except Exception:
    
    # Mensaje de error;
    
    print("\n¡ERROR!, digita una opcion valida"); 
    
  # Finalmente;
    
  finally:
    
    # Aviso de termino de programa;
    
    print("\n*****Finalizando programa*****"); 